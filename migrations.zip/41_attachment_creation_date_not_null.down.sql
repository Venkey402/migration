ALTER TABLE attachment ALTER COLUMN creation_date DROP NOT NULL;
