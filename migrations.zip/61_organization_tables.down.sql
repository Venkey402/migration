DROP TABLE IF EXISTS organization_attribute;

DROP TABLE IF EXISTS organization;
