DROP INDEX unique_rule_name_per_project;

ALTER TABLE sender_case DROP COLUMN rule_name;
