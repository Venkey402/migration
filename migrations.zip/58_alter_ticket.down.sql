ALTER TABLE ticket
    DROP COLUMN IF EXISTS plugin_name;