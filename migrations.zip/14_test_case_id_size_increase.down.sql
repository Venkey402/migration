ALTER TABLE test_item
    ALTER COLUMN test_case_id TYPE VARCHAR(512);