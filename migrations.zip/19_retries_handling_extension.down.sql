DROP FUNCTION IF EXISTS handle_retry(retry_id BIGINT, retry_parent_id BIGINT);
DROP FUNCTION IF EXISTS delete_item_statistics(test_item_id BIGINT);