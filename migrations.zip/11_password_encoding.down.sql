UPDATE users
SET password = '5d39d85bddde885f6579f8121e11eba2'
WHERE login = 'superadmin';
UPDATE users
SET password = '3fde6bb0541387e4ebdadf7c2ff31123'
WHERE login = 'default';