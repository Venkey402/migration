UPDATE issue_type
SET hex_color = '#00829b'
WHERE issue_group_id = 1 AND hex_color = '#ffb743';

UPDATE issue_type
SET hex_color = '#ffc208'
WHERE issue_group_id = 2 AND hex_color = '#f7d63e';

UPDATE issue_type
SET hex_color = '#d32f2f'
WHERE issue_group_id = 3 AND hex_color = '#ec3900';

UPDATE issue_type
SET hex_color = '#76839b'
WHERE issue_group_id = 4 AND hex_color = '#777777';

UPDATE issue_type
SET hex_color = '#3e7be6'
WHERE issue_group_id = 5 AND hex_color = '#0274d1';