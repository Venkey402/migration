ALTER TABLE attachment
    DROP COLUMN file_size;