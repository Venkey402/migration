UPDATE issue_type
SET hex_color = '#ffb743'
WHERE issue_group_id = 1 AND hex_color = '#00829b';

UPDATE issue_type
SET hex_color = '#f7d63e'
WHERE issue_group_id = 2 AND hex_color = '#ffc208';

UPDATE issue_type
SET hex_color = '#ec3900'
WHERE issue_group_id = 3 AND hex_color = '#d32f2f';

UPDATE issue_type
SET hex_color = '#777777'
WHERE issue_group_id = 4 AND hex_color = '#76839b';

UPDATE issue_type
SET hex_color = '#0274d1'
WHERE issue_group_id = 5 AND hex_color = '#3e7be6';