ALTER TABLE log DROP COLUMN cluster_id;

DROP TABLE IF EXISTS clusters_test_item;
DROP TABLE IF EXISTS clusters;