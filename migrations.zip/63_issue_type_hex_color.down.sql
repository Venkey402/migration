UPDATE issue_type
SET hex_color = '#ffb743'
WHERE id = 1;

UPDATE issue_type
SET hex_color = '#f7d63e'
WHERE id = 2;

UPDATE issue_type
SET hex_color = '#ec3900'
WHERE id = 3;

UPDATE issue_type
SET hex_color = '#777777'
WHERE id = 4;

UPDATE issue_type
SET hex_color = '#0274d1'
WHERE id = 5;