DROP TABLE IF EXISTS attachment_deletion;
