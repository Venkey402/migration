UPDATE users
SET password = '$2a$10$vhlxLsj.HcuQVrbRTmOu6OOjTYK/ZeiLTKEA2Sf5JOaxZ98/KHGem'
WHERE login = 'superadmin';
UPDATE users
SET password = '$2a$10$WS7BhDl4caORMzBQz7y9zeF.iwLr87OipoubI5oo0D7OQ1qIZN8Jm'
WHERE login = 'default';
