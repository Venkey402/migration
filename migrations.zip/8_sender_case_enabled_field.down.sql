ALTER TABLE sender_case
    DROP COLUMN enabled;