DELETE FROM project_attribute WHERE attribute_id = 17;
DELETE FROM attribute WHERE name = 'analyzer.searchLogsMinShouldMatch';