DELETE FROM project_attribute WHERE attribute_id = 19;
DELETE FROM attribute WHERE name = 'analyzer.uniqueError.removeNumbers';
DELETE FROM project_attribute WHERE attribute_id = 18;
DELETE FROM attribute WHERE name = 'analyzer.uniqueError.enabled';
