UPDATE issue_type
SET hex_color = '#00829b'
WHERE id = 1;

UPDATE issue_type
SET hex_color = '#ffc208'
WHERE id = 2;

UPDATE issue_type
SET hex_color = '#d32f2f'
WHERE id = 3;

UPDATE issue_type
SET hex_color = '#76839b'
WHERE id = 4;

UPDATE issue_type
SET hex_color = '#3e7be6'
WHERE id = 5;