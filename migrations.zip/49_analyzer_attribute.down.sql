DELETE FROM project_attribute WHERE attribute_id = 16;
DELETE FROM attribute WHERE name = 'analyzer.allMessagesShouldMatch';
