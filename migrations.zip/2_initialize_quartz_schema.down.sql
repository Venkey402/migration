-------------------------------------- QUARTZ SCHEMA ----------------------------------------

DROP TABLE IF EXISTS quartz.scheduler_fired_triggers;
DROP TABLE IF EXISTS quartz.scheduler_paused_trigger_grps;
DROP TABLE IF EXISTS quartz.scheduler_scheduler_state;
DROP TABLE IF EXISTS quartz.scheduler_locks;
DROP TABLE IF EXISTS quartz.scheduler_simple_triggers;
DROP TABLE IF EXISTS quartz.scheduler_cron_triggers;
DROP TABLE IF EXISTS quartz.scheduler_simprop_triggers;
DROP TABLE IF EXISTS quartz.scheduler_blob_triggers;
DROP TABLE IF EXISTS quartz.scheduler_triggers;
DROP TABLE IF EXISTS quartz.scheduler_job_details;
DROP TABLE IF EXISTS quartz.scheduler_calendars;